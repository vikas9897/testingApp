﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities
{
    public class OrderDetail: IEntityBase
    {
        public OrderDetail()
        {
            AddOns = new List<AddOn>();
        }
        public int ID { get; set; }
        public Nullable<DateTime> PaymentDate { get; set; }
        public Nullable<DateTime> ExpireDate { get; set; }
        public PaymentStatus PaymentStatus { get; set; }
        public bool IsPaymentReceived { get; set; }
        public int PaidAmount { get; set; }
        public int OrderID { get; set; }
        public int CustomerID { get; set; }
        public virtual Order Order { get; set; }
        public int PlanId { get; set; }
        public virtual Plan Plans { get; set; }
        
        public virtual IEnumerable<AddOn> AddOns { get; set;}
    }

    public enum PlanStatus
    {
        New,
        Activated,
        Expired
    }

    public enum PaymentStatus
    {
        Pending,
        Done,
        Declined
    }
}
