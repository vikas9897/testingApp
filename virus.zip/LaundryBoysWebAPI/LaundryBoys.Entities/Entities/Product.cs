﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities
{
    public class Plan: IEntityBase
    {
        public int ID { get; set; }
        
        public string PlanName { get; set; }
        
        public string Description { get; set; }

        public string Image { get; set; }

        public int Price { get; set; }

        public int Validity { get; set; }

        public string Discount { get; set; }

        public string PickUpDelivery { get; set; }
        
    }
}
