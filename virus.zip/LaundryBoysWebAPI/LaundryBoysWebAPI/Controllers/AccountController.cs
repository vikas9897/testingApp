﻿using System.Net.Http;
using System.Web.Http;
using LaundryBoysWebAPI.Models;
using LaundryBoysWebAPI.Web.Infrastructure.Core;
using LaundryBoys.Data.Repositories;
using LaundryBoys.Data.Infrastructure;
using Domain.Entities;
using System.Net;
using LaundryBoys.Services.Utilities;
using LaundryBoys.Services.Abstract;
using LaundryBoysWebAPI.Infrastructure.Extensions;
using System;

namespace TaxWebAPI.Controllers
{
    [Authorize(Roles = "Admin")]
    [RoutePrefix("api/Account")]
    public class AccountController : ApiControllerBase
    {
        private readonly IMembershipService _membershipService;
        private readonly IEntityBaseRepository<Customer> _customersRepository;

        public AccountController(IMembershipService membershipService, IEntityBaseRepository<Customer> customersRepository,
            IEntityBaseRepository<Error> _errorsRepository, IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _membershipService = membershipService;
            _customersRepository = customersRepository;
        }

        [AllowAnonymous]
        [Route("authenticate")]
        [HttpPost]
        public HttpResponseMessage Login(HttpRequestMessage request, LoginViewModel user)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (ModelState.IsValid)
                {
                    MembershipContext _userContext = _membershipService.ValidateUser(user.Username, user.Password);

                    if (_userContext.User != null)
                    {
                        response = request.CreateResponse(HttpStatusCode.OK, new { success = true });
                    }
                    else
                    {
                        response = request.CreateResponse(HttpStatusCode.OK, new { success = false });
                    }
                }
                else
                    response = request.CreateResponse(HttpStatusCode.OK, new { success = false });

                return response;
            });
        }

        [AllowAnonymous]
        [Route("register")]
        [HttpPost]
        public HttpResponseMessage Register(HttpRequestMessage request, RegistrationViewModel user)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    User _user = _membershipService.CreateUser(user.Mobile, user.Email, user.Password, new int[] { 2 });

                    if (_user != null)
                    {
                        CustomerViewModel customer = new CustomerViewModel
                        {
                            Email = _user.Email,
                            Mobile = _user.Mobile,
                            RegistrationDate = DateTime.Now,
                        };
                        
                        Customer newCustomer = new Customer();
                        newCustomer.UpdateCustomer(customer);
                        newCustomer.RegistrationDate = DateTime.Now;
                        newCustomer.User = _user;
                        _customersRepository.Add(newCustomer);

                        _unitOfWork.Commit();
                        response = request.CreateResponse(HttpStatusCode.OK, new { success = true });
                    }
                    else
                    {
                        response = request.CreateResponse(HttpStatusCode.OK, new { success = false });
                    }
                }

                return response;
            });
        }
    }
}
