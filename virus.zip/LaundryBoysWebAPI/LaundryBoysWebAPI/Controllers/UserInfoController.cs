﻿//using Microsoft.AspNet.Identity;
//using Microsoft.AspNet.Identity.EntityFramework;
//using System;
//using System.Collections.Generic;
//using System.Data;
//using System.Data.Entity;
//using System.Data.Entity.Infrastructure;
//using System.Data.Entity.Validation;
//using System.Linq;
//using System.Net;
//using System.Net.Http;
//using System.Threading.Tasks;
//using System.Web.Http;
//using System.Web.Http.Description;
//using LaundryBoysWebAPI.Filters;
//using LaundryBoysWebAPI.Models;
//using LaundryBoys.Data;
//using Domain;

//namespace LaundryBoysWebAPI.Controllers
//{
//    [Authorize]
//    [RoutePrefix("api/user")]
//    public class UserInfoController : ApiController
//    {
//        private StoreContext db;
//        private UserManager<ApplicationUser> userManager;
//        public UserInfoController()
//        {
//            db = new StoreContext();
//            userManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(db));
//        }
//        // GET: api/UserInfo
//        [Route("getdetails")]
//        [HttpGet]
//        [ResponseType(typeof(UserInfo))]
//        public async Task<IHttpActionResult> GetUserInfos()
//        {
//            ApplicationUser user = await userManager.FindByIdAsync(User.Identity.GetUserId());
//            UserInfoShort userInfo = new UserInfoShort();
//            string message = "Success";
//            if (user != null)
//            {
//                userInfo = await db.UserInfo.Include("User").Where(s => s.User.Id == user.Id).Select(c => new UserInfoShort { Name = c.Name, Address = c.Address, Pincode = c.Pincode , Phone = c.Phone }).FirstOrDefaultAsync();
//                if(userInfo == null)
//                {
//                    userInfo = new UserInfoShort() { Name = user.Name, Phone = user.PhoneNumber};
//                }
//            }
//            else
//            {
//                message = "UserId is null. Please check authentication.";
//            }

//            return Ok(new {Status = message, UserInfo = userInfo });
//        }


//        // PUT: api/UserInfo/5
//        [Route("updatedetails")]
//        [HttpPut]
//        [ResponseType(typeof(void))]
//        public async Task<IHttpActionResult> PutUserInfo(UserInfo userInfo)
//        {
//            var message = "Success";

//            if (!ModelState.IsValid)
//            {
//                return BadRequest(ModelState);
//            }
//            ApplicationUser user = await userManager.FindByIdAsync(User.Identity.GetUserId());

//            if (user == null)
//            {
//                message = "No user found";
//                return null;
//            }

//            if (!UserInfoExists(user.Id))
//            {
//                return BadRequest();
//            }
//            var info = db.UserInfo.Include("User").FirstOrDefault(d => d.InfoId == user.Id);

//            //userInfo.User = user;

//            db.Entry(info).State = EntityState.Modified;

//            try
//            {
//                await db.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!UserInfoExists(user.Id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return Ok(new { Status = message, Message = "Data updated successfully." });
//        }

//        // POST: api/UserInfo
//        [Route("savedetails")]
//        [HttpPost]
//        [ResponseType(typeof(UserInfo))]
//        //[CheckModelForNull]
//        [ValidateModelState]
//        public async Task<IHttpActionResult> PostUserInfo(UserInfo userInfo)
//        {
//            var message = "Success";

//            if (!ModelState.IsValid)
//            {
//                return BadRequest(ModelState);
//            }

//            ApplicationUser user = await userManager.FindByIdAsync(User.Identity.GetUserId());

//            if (user == null)
//            {
//                message = "No user found";
//                return null;
//            }

//            try
//            {
//                if (UserInfoExists(user.Id))
//                {
//                    UserInfo info = db.UserInfo.Include("User").FirstOrDefault(d => d.InfoId == user.Id);

//                    if(!string.IsNullOrEmpty(userInfo.Address))
//                    {
//                        info.Address = userInfo.Address;
//                    }
//                    if (!string.IsNullOrEmpty(userInfo.Name))
//                    {
//                        info.Name = userInfo.Name;
//                    }
                   
//                    if (!string.IsNullOrEmpty(userInfo.Phone))
//                    {
//                        info.Phone = userInfo.Phone;
//                    }

//                    db.Entry(info).State = EntityState.Modified;
//                    message = "Data updated successfully.";
//                }
//                else
//                {
//                    userInfo.User = user;
//                    userInfo.Name = userInfo.Name == null ? user.Name : userInfo.Name;
//                    userInfo.Phone = user.PhoneNumber == null ? user.PhoneNumber : userInfo.Phone;
//                    db.UserInfo.Add(userInfo);
//                    message = "Data saved successfully.";
//                }
//            }
//            catch(DbEntityValidationException ex)
//            {
//                message = ex.Message;
//            }

//            try
//            {
//                await db.SaveChangesAsync();   
//            }
//            catch (DbEntityValidationException ex)
//            {
//                message = ex.Message;
//            }
//            return Ok(new { Status = "Success", Message = message });
//        }



//        protected override void Dispose(bool disposing)
//        {
//            if (disposing)
//            {
//                db.Dispose();
//            }
//            base.Dispose(disposing);
//        }

//        private bool UserInfoExists(string id)
//        {
//            return db.UserInfo.Count(e => e.InfoId == id) > 0;
//        }
//    }
//}