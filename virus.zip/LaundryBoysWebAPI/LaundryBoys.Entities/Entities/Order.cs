﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities
{
    public class Order: IEntityBase
    {
        public int ID { get; set; }
        public string FullName { get; set; }
        public string Address { get; set; }
        public string Mobile { get; set; }
        public int PayableAmount { get; set; }
        public PlanStatus OrderStatus { get; set; }
        public DateTime OrderDate { get; set; }
        public int CustomerId { get; set; }
    }
   
}
