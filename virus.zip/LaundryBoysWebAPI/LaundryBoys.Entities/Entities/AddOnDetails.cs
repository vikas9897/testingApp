﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities
{
    public class AddOnDetails: IEntityBase
    {
        public int ID { get; set; }

        public int OrderID { get; set; }

        public int AddOnsId { get; set; }

        public virtual AddOn AddOn { get; set;}
    }
}
