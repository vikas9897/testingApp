﻿using Domain.Entities;
using LaundryBoys.Data.Infrastructure;
using LaundryBoys.Data.Repositories;
using LaundryBoysWebAPI.Web.Infrastructure.Core;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.Description;

namespace LaundryBoysWebAPI.Controllers
{

    [Authorize(Roles = "Admin, Customer")]
    [RoutePrefix("api/products")]
    public class ProductsController : ApiControllerBase
    {
        private readonly IEntityBaseRepository<Plan> _productsRepository;

        public ProductsController(IEntityBaseRepository<Plan> productsRepository,
            IEntityBaseRepository<Error> _errorsRepository, IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _productsRepository = productsRepository;
        }

        // GET: api/plans
        [Route("Plans")]
        [HttpGet]
        public HttpResponseMessage GetProducts(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var CurrentUser = HttpContext.Current.User.Identity;
                var products = _productsRepository.GetAll().OrderByDescending(m => m.ID).ToList();
                
                response = request.CreateResponse<IEnumerable<Plan>>(HttpStatusCode.OK, products);

                return response;
            });
        }

        // GET: api/Plans/5
        [Route("Plans/{id:int}")]
        [ResponseType(typeof(Plan))]
        public HttpResponseMessage GetProduct(HttpRequestMessage request, int id)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var product = _productsRepository.GetSingle(id);
                
                response = request.CreateResponse<Plan>(HttpStatusCode.OK, product);

                return response;
            });
        }

        // PUT: api/Plans/5
        //[Route("Plans")]
        //[ResponseType(typeof(void))]
        //public async Task<IHttpActionResult> PutProduct(int id, Product gadget)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    if (id != gadget.ProductId)
        //    {
        //        return BadRequest();
        //    }

        //    db.Entry(gadget).State = EntityState.Modified;

        //    try
        //    {
        //        await db.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!ProductExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return StatusCode(HttpStatusCode.NoContent);
        //}

        //// POST: api/Plans
        //[Route("Plans")]
        //[ResponseType(typeof(Product))]
        //public async Task<IHttpActionResult> PostProduct(Product gadget)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    db.Products.Add(gadget);
        //    await db.SaveChangesAsync();

        //    return CreatedAtRoute("DefaultApi", new { id = gadget.ProductId }, gadget);
        //}

        //// DELETE: api/Plans/5
        //[Route("Plans")]
        //[ResponseType(typeof(Product))]
        //public async Task<IHttpActionResult> DeleteProduct(int id)
        //{
        //    Product gadget = await db.Products.FindAsync(id);
        //    if (gadget == null)
        //    {
        //        return NotFound();
        //    }

        //    db.Products.Remove(gadget);
        //    await db.SaveChangesAsync();

        //    return Ok(gadget);
        //}

        
    }
}