﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using FluentValidation;
using LaundryBoysWebAPI.Models;

namespace LaundryBoysWebAPI.Infrastructure.Validators
{
    public class RegistrationViewModelValidator : AbstractValidator<RegistrationViewModel>
    {
        public RegistrationViewModelValidator()
        {
            RuleFor(r => r.Email).NotEmpty().EmailAddress()
                .WithMessage("Invalid email address");

            RuleFor(r => r.Mobile).NotEmpty()
                .WithMessage("Invalid mobile number");

            RuleFor(r => r.Password).NotEmpty()
                .WithMessage("Invalid password");

            //RuleFor(r => r.UserName).NotEmpty()
            //    .WithMessage("Please enter your name.");
        }
    }

    public class LoginViewModelValidator : AbstractValidator<LoginViewModel>
    {
        public LoginViewModelValidator()
        {
            RuleFor(r => r.Username).NotEmpty()
                .WithMessage("Invalid username");

            RuleFor(r => r.Password).NotEmpty()
                .WithMessage("Invalid password");
        }
    }
}