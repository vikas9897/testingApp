﻿using LaundryBoys.Data.Configurations;
using LaundryBoys.Data.Migrations;
using Domain.Entities;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;


namespace LaundryBoys.Data
{
    public class StoreContext : DbContext
    {
        public StoreContext()
            : base("LaundryBoysWebAPI")
        {
            Database.SetInitializer(new Configuration());
            
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            modelBuilder.Configurations.Add(new UserConfiguration());
            modelBuilder.Configurations.Add(new UserRoleConfiguration());
            modelBuilder.Configurations.Add(new RoleConfiguration());
            //modelBuilder.Configurations.Add(new CustomerConfiguration());
            //modelBuilder.Entity<OrderDetail>()
            //         .HasMany(q => q.AddOns).WithOptional(p => p.OrderDetail);
            
    }

        #region Entity Sets
        public IDbSet<User> UserSet { get; set; }
        public IDbSet<Role> RoleSet { get; set; }
        public IDbSet<UserRole> UserRoleSet { get; set; }

        public IDbSet<Customer> Customer { get; set; }
        public IDbSet<Error> ErrorSet { get; set; }

        public IDbSet<Plan> Plans { get; set; }
        public IDbSet<AddOn> AddOns { get; set; }
        public IDbSet<Order> Order { get; set; }
        public IDbSet<OrderDetail> OrderDetail { get; set; }
        public IDbSet<AddOnDetails> AddOnsDetails { get; set; }
        
        #endregion

        public virtual void Commit()
        {
            base.SaveChanges();
        }
        
    }
}
