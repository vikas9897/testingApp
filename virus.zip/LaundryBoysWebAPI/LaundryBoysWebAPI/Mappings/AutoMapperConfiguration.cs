﻿
using Domain.Entities;
using LaundryBoysWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LaundryBoysWebAPI.Mappings
{
    public class AutoMapperConfiguration
    {
        public static void Configure()
        {
            //Mapper.Initialize(cfg => {
            //    cfg.CreateMap<Customer, CustomerViewModel>();
            //});
            
        }
    }
}