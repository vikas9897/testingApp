﻿using System.Net.Http;
using System.Web.Http;
using LaundryBoysWebAPI.Models;
using LaundryBoysWebAPI.Web.Infrastructure.Core;
using LaundryBoys.Data.Repositories;
using LaundryBoys.Data.Infrastructure;
using Domain.Entities;
using System.Net;
using System.Collections.Generic;
using LaundryBoys.Data.Extensions;

using System.Linq;
using LaundryBoysWebAPI.Infrastructure.Extensions;

namespace TaxWebAPI.Controllers
{
    [Authorize(Roles = "Admin, Customer")]
    [RoutePrefix("api/customers")]
    public class CustomersController : ApiControllerBase
    {
        private readonly IEntityBaseRepository<Customer> _customersRepository;
        private readonly IEntityBaseRepository<User> _userRepository;

        public CustomersController(IEntityBaseRepository<Customer> customersRepository,
            IEntityBaseRepository<User> userRepository,
            IEntityBaseRepository<Error> _errorsRepository, IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _customersRepository = customersRepository;
            _userRepository = userRepository;
        }

        [Authorize(Roles = "Admin")]
        [Route("customerslist")]
        [HttpGet]
        public HttpResponseMessage CustList(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                var customers = _customersRepository.GetAll().OrderByDescending(m => m.RegistrationDate).ToList();
                var customerList = customers.Select(s => new Customer {ID = s.ID ,FirstName= s.FirstName, LastName = s.LastName, Address = s.Address,
                City = s.City, Email = s.Email, Mobile = s.Mobile, RegistrationDate = s.RegistrationDate, ZipCode = s.ZipCode}).ToList();
                response = request.CreateResponse<IEnumerable<Customer>>(HttpStatusCode.OK, customerList);

                return response;
            });
        }

        [Route("customerdetails")]
        [HttpGet]
        public HttpResponseMessage CustDetails(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var CurrentUser = User.Identity.Name;
                var user = _userRepository.GetCurrentUser(CurrentUser);
                if (user == null)
                {
                    response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid user");
                }
                else
                {
                    var customer = _customersRepository.GetSingle(user.ID);

                    if (customer == null)
                    {
                        response = request.CreateErrorResponse(HttpStatusCode.NotFound, "No details found.");
                    }
                    else
                    {
                        var customerDetails =  
                                    new Customer {ID = customer.ID ,FirstName= customer.FirstName, 
                                        LastName = customer.LastName, Address = customer.Address,
                                    City = customer.City, Email = customer.Email, Mobile = customer.Mobile, 
                                    RegistrationDate = customer.RegistrationDate, 
                                    ZipCode = customer.ZipCode};
                        response = request.CreateResponse<Customer>(HttpStatusCode.OK, customerDetails);
                    }
                }
                return response;
            });
        }

        [HttpPost]
        [Route("customerupdate")]
        public HttpResponseMessage CustUpdate(HttpRequestMessage request, CustomerViewModel customer)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest,
                        ModelState.Keys.SelectMany(k => ModelState[k].Errors)
                              .Select(m => m.ErrorMessage).ToArray());
                }
                else
                {
                    var CurrentUser = User.Identity.Name;
                    var user = _userRepository.GetCurrentUser(CurrentUser);
                    Customer _customer = _customersRepository.GetSingle(user.ID);
                    if (user == null || _customer == null)
                    {
                        response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid user or customer.");
                    }
                    else
                    {
                       _customer.UpdateCustomer(customer);
                        _unitOfWork.Commit();
                        response = request.CreateResponse(HttpStatusCode.OK, "Customer Details Updated Successfully.");
                    }
                }

                return response;
            });
        }

        
    }
}
