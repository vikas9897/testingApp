﻿using Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LaundryBoysWebAPI.Models
{
    public class OrderViewModel
    {
        public OrderViewModel()
        {
            AddOns = new List<AddOn>();
        }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string Mobile { get; set; }
        public string PinCode { get; set; }
        public DateTime OrderDate { get; set; }
        public int PayableAmount { get; set; }
        public int PlanId { get; set; }
        public virtual ICollection<AddOn> AddOns { get; set; }
        public virtual Plan Plan { get; set; }
    }
}