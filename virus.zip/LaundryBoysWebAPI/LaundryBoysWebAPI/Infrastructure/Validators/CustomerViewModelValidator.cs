﻿using FluentValidation;
using LaundryBoysWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LaundryBoysWebAPI.Infrastructure.Validators
{
    public class CustomerViewModelValidator : AbstractValidator<CustomerViewModel>
    {
        public CustomerViewModelValidator()
        {
            //RuleFor(customer => customer.FirstName).NotEmpty()
            //    .Length(1, 100).WithMessage("First Name must be between 1 - 100 characters");

            //RuleFor(customer => customer.LastName).NotEmpty()
            //    .Length(1, 100).WithMessage("Last Name must be between 1 - 100 characters");

            //RuleFor(customer => customer.Address).NotEmpty()
            //    .Length(1, 500).WithMessage("Address must be between 1 - 500 characters");

            //RuleFor(customer => customer.City).NotEmpty()
            //    .Length(1, 100).WithMessage("City must be between 1 - 100 characters");


            //RuleFor(customer => customer.Mobile).NotEmpty().Matches(@"^\d{10}$")
            //    .Length(10).WithMessage("Mobile phone must have 10 digits");

            //RuleFor(customer => customer.Email).NotEmpty().EmailAddress()
            //    .WithMessage("Enter a valid Email address");

        }
    }
}