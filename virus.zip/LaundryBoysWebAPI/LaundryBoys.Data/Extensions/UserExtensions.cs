﻿using LaundryBoys.Data.Repositories;
using Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaundryBoys.Data.Extensions
{
    public static class UserExtensions
    {
        public static User GetSingleByUsername(this IEntityBaseRepository<User> userRepository, string username)
        {
            return userRepository.GetAll().FirstOrDefault(x => x.Email == username || x.Mobile == username);
        }

        public static User GetCurrentUser(this IEntityBaseRepository<User> userRepository, string CurrentUser)
        {
            return userRepository.GetAll().FirstOrDefault(x => x.Mobile == CurrentUser || x.Email == CurrentUser);
        }
    }
}
