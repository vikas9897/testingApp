﻿using LaundryBoys.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaundryBoys.Data.Infrastructure
{
    public class DbFactory : Disposable, IDbFactory
    {
        StoreContext dbContext;

        public StoreContext Init()
        {
            return dbContext ?? (dbContext = new StoreContext());
        }

        protected override void DisposeCore()
        {
            if (dbContext != null)
                dbContext.Dispose();
        }
    }
}
