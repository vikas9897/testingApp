﻿using Domain.Entities;
using LaundryBoys.Data.Infrastructure;
using LaundryBoys.Data.Repositories;
using LaundryBoys.Services.Abstract;
using LaundryBoys.Data.Extensions;
using LaundryBoysWebAPI.Models;
using LaundryBoysWebAPI.Web.Infrastructure.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.Description;
using LaundryBoysWebAPI.Infrastructure.Extensions;

namespace laundryboyswebapi.controllers
{
    
    [RoutePrefix("api/order")]
    [Authorize(Roles = "Admin, Customer")]
    public class OrdersController : ApiControllerBase
    {
        private readonly IEntityBaseRepository<Order> _ordersRepository;
        private readonly IEntityBaseRepository<Plan> _productsRepository;
        private readonly IEntityBaseRepository<User> _userRepository;
        private readonly IEntityBaseRepository<OrderDetail> _orderDetailRepository;
        private readonly IEntityBaseRepository<AddOnDetails> _addOnDetailRepository;
        private readonly IEntityBaseRepository<AddOn> _addOnRepository;
        private readonly IEntityBaseRepository<Customer> _customerRepository;

        public OrdersController(IEntityBaseRepository<Order> ordersRepository, 
            IEntityBaseRepository<Plan> plansRepository,
            IEntityBaseRepository<User> userRepository,
            IEntityBaseRepository<OrderDetail> orderDetailRepository,
            IEntityBaseRepository<Customer> customersRepository,
            IEntityBaseRepository<AddOnDetails> addOnsDetailsRepository,
            IEntityBaseRepository<AddOn> addOnsRepository,
            IEntityBaseRepository<Error> _errorsRepository, IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _ordersRepository = ordersRepository;
            _productsRepository = plansRepository;
            _userRepository = userRepository;
            _orderDetailRepository = orderDetailRepository;
            _addOnDetailRepository = addOnsDetailsRepository;
            _addOnRepository = addOnsRepository;
            _customerRepository = customersRepository;


        }

        // get: api/orders
        [Route("orderlist")]
        [HttpGet]
        public HttpResponseMessage GetOrders(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var CurrentUser = User.Identity.Name;
                var user = _userRepository.GetCurrentUser(CurrentUser);
                var ordersList = _orderDetailRepository.GetAll().Where(s => s.Order.CustomerId == user.ID && s.Order.OrderStatus != 0).OrderByDescending(m => m.Order.OrderDate).ToList();
                if (user == null)
                {
                    response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid user");
                }
                else if (ordersList.Count == 0)
                {
                    response = request.CreateErrorResponse(HttpStatusCode.NotFound, "No order found.");
                }
                else
                {
                    foreach (var order in ordersList)
                    {
                        if (DateTime.Now > order.ExpireDate && order.Order.OrderStatus == PlanStatus.Activated)
                        {
                            order.Order.OrderStatus = PlanStatus.Expired;
                            _unitOfWork.Commit();
                        }
                        var addOnDetails = _addOnDetailRepository.GetAll().Where(s => s.OrderID == order.ID).ToList();
                        if (addOnDetails != null)
                        {
                            List<AddOn> addOns = new List<AddOn>();
                            foreach (var addOn in addOnDetails)
                            {
                                addOns.Add(addOn.AddOn);
                            }
                            order.AddOns = addOns;
                        }
                    }

                    response = request.CreateResponse<IEnumerable<OrderDetail>>(HttpStatusCode.OK, ordersList);
                }

                return response;
            });
        }

        // get: api/orderDetails
        //[Route("orderDetails/{orderId:int}")]
        //[HttpGet]
        //public HttpResponseMessage OrderDetails(HttpRequestMessage request, int orderId)
        //{
        //    return CreateHttpResponse(request, () =>
        //    {
        //        HttpResponseMessage response = null;
        //        var CurrentUser = User.Identity.Name;
        //        var user = _userRepository.GetCurrentUser(CurrentUser);
                
        //        if (user == null)
        //        {
        //            response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid user");
        //        }
        //        else
        //        {
        //            var orderDetails = _orderDetailRepository.GetAll().Where(s => s.Order.ID == orderId && s.Order.CustomerId == user.ID).FirstOrDefault();
        //            if (orderDetails == null)
        //            {
        //                response = request.CreateErrorResponse(HttpStatusCode.NotFound, "No Order Details found.");
        //            }
        //            else
        //            {
        //                var addOnDetails = _addOnDetailRepository.GetAll().Where(s => s.OrderID == orderId).ToList();
        //                if (addOnDetails != null)
        //                {
        //                    List<AddOn> addOns = new List<AddOn>();
        //                    foreach (var addOn in addOnDetails)
        //                    {
        //                        addOns.Add(addOn.AddOn);
        //                    }
        //                    orderDetails.AddOns = addOns;
        //                }
                        
        //                response = request.CreateResponse(HttpStatusCode.OK, orderDetails);
        //            }
        //        }

        //        return response;
        //    });
        //}

        // get: api/orders
        [Authorize(Roles = "Admin")]
        [Route("allorder")]
        [HttpGet]
        public HttpResponseMessage GetAllOrders(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var CurrentUser = User.Identity.Name;
                var user = _userRepository.GetCurrentUser(CurrentUser);
                var ordersList = _orderDetailRepository.GetAll().OrderByDescending(m => m.Order.OrderDate).ToList();
                if (user == null)
                {
                    response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid user");
                }
                else if (ordersList.Count == 0)
                {
                    response = request.CreateErrorResponse(HttpStatusCode.NotFound, "No order found.");
                }
                else
                {
                    foreach (var order in ordersList)
                    {
                        if (DateTime.Now > order.ExpireDate && order.Order.OrderStatus == PlanStatus.Activated)
                        {
                            order.Order.OrderStatus = PlanStatus.Expired;
                            _unitOfWork.Commit();
                        }
                        var addOnDetails = _addOnDetailRepository.GetAll().Where(s => s.OrderID == order.ID).ToList();
                        if (addOnDetails != null)
                        {
                            List<AddOn> addOns = new List<AddOn>();
                            foreach (var addOn in addOnDetails)
                            {
                                addOns.Add(addOn.AddOn);
                            }
                            order.AddOns = addOns;
                        }
                    }
                    response = request.CreateResponse<IEnumerable<OrderDetail>>(HttpStatusCode.OK, ordersList);
                }

                return response;
            });
        }

        // get: api/orders/5
        [Route("updateorder/{id:int}/{amount:int}")]
        [HttpPost]
        public HttpResponseMessage UpdateOrder(HttpRequestMessage request, int id, int amount)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var CurrentUser = User.Identity.Name;
                var user = _userRepository.GetCurrentUser(CurrentUser);
                var orderDetails = new OrderDetail();
                if (user.ID == 1)
                    orderDetails = _orderDetailRepository.GetAll().Where(s => s.OrderID == id).FirstOrDefault();
                else
                    orderDetails = _orderDetailRepository.GetAll().Where(s => s.OrderID == id && s.Order.CustomerId == user.ID).FirstOrDefault();

                if (orderDetails == null)
                {
                    response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Order not found.");
                }
                else
                {
                    var plan = _productsRepository.GetSingle(orderDetails.PlanId);
                    var isValidAmount = amount >= orderDetails.Order.PayableAmount;

                    if ((isValidAmount && !orderDetails.IsPaymentReceived) || (isValidAmount && user.ID == 1))
                    {
                        DateTime startDate = DateTime.Now;
                        DateTime expiryDate = startDate.AddDays(plan.Validity);
                        orderDetails.PaidAmount = amount;
                        orderDetails.PaymentDate = startDate;
                        orderDetails.IsPaymentReceived = true;
                        orderDetails.PaymentStatus = PaymentStatus.Done;
                        orderDetails.ExpireDate = expiryDate;
                        orderDetails.Order.OrderStatus = PlanStatus.Activated;
                        _unitOfWork.Commit();
                        response = request.CreateResponse(HttpStatusCode.OK, "Order updated successfully.");
                    }
                    else
                    {
                        if (orderDetails.IsPaymentReceived && user.ID > 1)
                            response = request.CreateResponse(HttpStatusCode.BadRequest, "User has already paid for this plan.");
                        else
                            response = request.CreateResponse(HttpStatusCode.BadRequest, "Amount should not be less than payable amount.");
                    }
                }
                return response;
            });
        }

        [HttpGet]
        [Route("addOrder/{planId:int}")]
        public HttpResponseMessage Add(HttpRequestMessage request, int planId)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var CurrentUser = User.Identity.Name;
                var user = _userRepository.GetCurrentUser(CurrentUser);

                if (user == null)
                {
                    response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid user");
                }
                else
                {
                    var Addons = _addOnRepository.GetAll().ToList();
                    var plan = _productsRepository.GetSingle(planId);
                    Customer _customer = _customerRepository.GetSingle(user.ID);
                    var newOrder = new OrderViewModel();
                    if (_customer != null)
                    {
                        newOrder.FirstName = _customer.FirstName;
                        newOrder.LastName = _customer.LastName;
                        newOrder.Address = _customer.Address;
                        newOrder.City = _customer.City;
                        newOrder.Mobile = _customer.Mobile;
                        newOrder.PinCode = _customer.ZipCode;
                        newOrder.PlanId = planId;
                        newOrder.Plan = plan;
                        newOrder.AddOns = Addons;
                    }
                    response = request.CreateResponse<OrderViewModel>(HttpStatusCode.OK, newOrder);
                }
                return response;
            });
        }

        [HttpPost]
        [Route("addOrder")]
        public HttpResponseMessage Add(HttpRequestMessage request, OrderViewModel order)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                }
                else
                {
                    var CurrentUser = User.Identity.Name;
                    var user = _userRepository.GetAll().FirstOrDefault(x => x.Mobile == CurrentUser || x.Email == CurrentUser);
                    
                    if (user == null || order.PlanId == 0)
                    {
                        response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid User or planId");
                    }
                    else {
                        Order newOrder = new Order();
                        newOrder.UpdateOrder(order);
                        newOrder.CustomerId = user.ID;
                        _ordersRepository.Add(newOrder);
                        _unitOfWork.Commit();

                        
                        foreach (var addOn in order.AddOns)
                        {
                            var newAdd = _addOnRepository.GetSingle(addOn.ID);
                            _addOnDetailRepository.Add(new AddOnDetails
                            {
                                OrderID = newOrder.ID,
                                AddOnsId = addOn.ID,
                                AddOn = newAdd
                            });
                        }

                        OrderDetail orderDetail = new OrderDetail()
                        {
                            OrderID = newOrder.ID,
                            //Order = newOrder,
                            PaymentStatus = PaymentStatus.Pending,
                            PlanId = order.PlanId,
                            IsPaymentReceived = false
                        };

                        Customer _customer = _customerRepository.GetSingle(user.ID);
                        if (_customer != null)
                        {
                            _customer.FirstName = _customer.FirstName == null? order.FirstName: _customer.FirstName;
                            _customer.LastName = _customer.LastName == null ? order.LastName : _customer.LastName;
                            _customer.Address = _customer.Address == null ? order.Address: _customer.Address;
                            _customer.City = _customer.City == null ? order.City : _customer.City;
                            _customer.ZipCode = _customer.ZipCode == null ? order.PinCode: _customer.ZipCode;
                        }
                        _orderDetailRepository.Add(orderDetail);
                        _unitOfWork.Commit();
                        response = request.CreateResponse(HttpStatusCode.Created, newOrder.ID);
                    }
                }

                return response;
            });
        }
 
    }
}