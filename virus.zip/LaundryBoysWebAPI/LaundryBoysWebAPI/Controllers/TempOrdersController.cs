﻿using Domain;
using LaundryBoysWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;

namespace LaundryBoysWebAPI.Controllers
{
    //[Authorize]
    //[RoutePrefix("api/sessions")]
    public class TempOrdersController : ApiController
    {
        // GET: api/TempOrders
        //[Route("TempOrders")]
        public List<CartItem> GetTempOrders()
        {
            List<CartItem> cartItems = new List<CartItem>();

            if (System.Web.HttpContext.Current.Session["Cart"] != null)
            {
                cartItems = (List<CartItem>)System.Web.HttpContext.Current.Session["Cart"];
            }

            return cartItems;
        }

        // POST: api/TempOrders
        [HttpPost]
        //[Route("TempOrders")]
        public HttpResponseMessage SaveOrder(List<CartItem> cartItems)
        {
            if (!ModelState.IsValid)
            {
                return new HttpResponseMessage(HttpStatusCode.BadRequest);
            }

            System.Web.HttpContext.Current.Session["Cart"] = cartItems;

            return new HttpResponseMessage(HttpStatusCode.OK);
        }
    }
}