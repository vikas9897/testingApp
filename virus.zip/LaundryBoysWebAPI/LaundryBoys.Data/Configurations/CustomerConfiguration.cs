﻿using Domain.Entities;

namespace LaundryBoys.Data.Configurations
{
    public class CustomerConfiguration : Configurations.EntityBaseConfiguration<Customer>
    {
        public CustomerConfiguration()
        {
            Property(u => u.FirstName).IsRequired().HasMaxLength(100);
            Property(u => u.LastName).IsRequired().HasMaxLength(100);
            Property(u => u.Address).IsRequired().HasMaxLength(500);
            Property(u => u.City).IsRequired();
            Property(c => c.Mobile).HasMaxLength(10);
            Property(c => c.Email).IsRequired().HasMaxLength(200);
        }
    }
}
