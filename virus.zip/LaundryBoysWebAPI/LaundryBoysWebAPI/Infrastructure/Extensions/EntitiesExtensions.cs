﻿using Domain.Entities;
using LaundryBoysWebAPI.Infrastructure.Validators;
using LaundryBoysWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LaundryBoysWebAPI.Infrastructure.Extensions
{
    public static class EntitiesExtensions
    {
        public static void UpdateOrder(this Order customer, OrderViewModel orderVm)
        {
            customer.FullName = orderVm.FirstName + " " + orderVm.LastName;
            customer.Address = orderVm.Address;
            customer.Mobile = orderVm.Mobile;
            customer.PayableAmount = orderVm.PayableAmount;
            customer.OrderDate = DateTime.Now;
            customer.OrderStatus = PlanStatus.New;
        }

        public static void UpdateCustomer(this Customer customer, CustomerViewModel customerVm)
        {
            customer.FirstName = customerVm.FirstName == null ? customer.FirstName : customerVm.FirstName;
            customer.LastName = customerVm.LastName == null ? customer.LastName: customerVm.LastName;
            customer.Address = customerVm.Address == null ? customer.Address: customerVm.Address;
            customer.Mobile = customerVm.Mobile == null ? customer.Mobile: customerVm.Mobile;
            customer.Email = customerVm.Email == null ? customer.Email: customerVm.Email;
            customer.City = customerVm.City == null ? customer.City: customerVm.City;
            //customer.RegistrationDate = (customer.RegistrationDate == DateTime.MinValue ? DateTime.Now : customerVm.RegistrationDate);
        }
    }
}