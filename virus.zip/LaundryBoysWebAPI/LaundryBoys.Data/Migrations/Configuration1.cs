namespace LaundryBoys.Data.Migrations
{
    using Domain.Entities;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;


    internal sealed class Configuration : DropCreateDatabaseIfModelChanges<LaundryBoys.Data.StoreContext>
    {
        //public Configuration()
        //{
        //    //AutomaticMigrationsEnabled = false;
        //}

        protected override void Seed(LaundryBoys.Data.StoreContext context)
        {

            // create movies
            context.Plans.AddOrUpdate(m => m.PlanName, GenerateProducts());

            //Create add on
            context.AddOns.AddOrUpdate(m => m.Name, GenerateAddOns());

            // create roles
            context.RoleSet.AddOrUpdate(r => r.Name, GenerateRoles());

            // username: chsakell, password: homecinema
            context.UserSet.AddOrUpdate(u => u.Email, new User[]{
                new User()
                {
                    Email="admin@laundryboys.com",
                    Mobile="0123456789",
                    HashedPassword ="k6/Kns/So6Gogp/e6S1sDugSJcLjZE5DcTaSgnKALZ4=",
                    Salt = "Pj3gdbafTYIXWSEqzaX64Q==",
                    IsLocked = false,
                    DateCreated = DateTime.Now
                }
            });

            // // create user-admin for chsakell
            context.UserRoleSet.AddOrUpdate(new UserRole[] {
                new UserRole() {
                    RoleId = 1, // admin
                    UserId = 1  // admin
                }
            });
            context.SaveChanges();

        }




        private Plan[] GenerateProducts()
        {
            Plan[] _product = new Plan[]
            {
                new Plan {
                    PlanName = "Plan1",
                    Description = "Description",
                    Price = 1000,
                    Image= "asus-memo.jpg",
                    Discount = "25%",
                    Validity = 30,
                    PickUpDelivery = "Weekly"
                },
                new Plan {
                    PlanName = "Plan2",
                    Description = "Description",
                    Price = 2000,
                    Image= "asus-memo.jpg",
                    Discount = "25%",
                    Validity = 30,
                    PickUpDelivery = "Weekly"
                },
                new Plan {
                    PlanName = "Plan3",
                    Description = "Description",
                    Price = 3000,
                    Image= "asus-memo.jpg",
                    Discount = "25%",
                    Validity = 30,
                    PickUpDelivery = "Weekly"
                },
                new Plan {
                    PlanName = "Plan4",
                    Description = "Description",
                    Price = 4000,
                    Image= "asus-memo.jpg",
                    Discount = "25%",
                    Validity = 30,
                    PickUpDelivery = "Weekly"
                },
                new Plan {
                    PlanName = "Plan5",
                    Description = "Description",
                    Price = 5000,
                    Image= "asus-memo.jpg",
                    Discount = "25%",
                    Validity = 30,
                    PickUpDelivery = "Weekly"
                },
                new Plan {
                    PlanName = "Plan6",
                    Description = "Description",
                    Price = 6000,
                    Image= "asus-memo.jpg",
                    Discount = "25%",
                    Validity = 30,
                    PickUpDelivery = "Weekly"
                }
            };
            return _product.ToArray();
        }
        private Role[] GenerateRoles()
        {
            Role[] _roles = new Role[]{
                new Role()
                {
                    Name="Admin"
                },
                new Role()
                {
                    Name="Customer"
                }
            };

            return _roles;
        }

        private AddOn[] GenerateAddOns()
        {
            AddOn[] _addOns = new AddOn[]{
                new AddOn()
                {
                    Name="AddOn1",
                    Description = "Description",
                    IsSelected = false,
                    Amount= 10
                },
                new AddOn()
                {
                    Name="AddOn2",
                    Description = "Description",
                    IsSelected = false,
                    Amount= 10
                },
                new AddOn()
                {
                    Name="AddOn3",
                    Description = "Description",
                    IsSelected = false,
                    Amount= 10
                }
            };

            return _addOns;
        }
    }
}
