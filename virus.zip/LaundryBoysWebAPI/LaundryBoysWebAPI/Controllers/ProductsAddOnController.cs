﻿using Domain.Entities;
using LaundryBoys.Data.Infrastructure;
using LaundryBoys.Data.Repositories;
using LaundryBoysWebAPI.Web.Infrastructure.Core;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;

namespace LaundryBoysWebAPI.Controllers
{

    //[Authorize(Roles = "Admin, Customer")]
    [RoutePrefix("api/Addon")]
    public class ProductsAddOnController : ApiControllerBase
    {
        private readonly IEntityBaseRepository<AddOn> _productsAddOnRepository;

        public ProductsAddOnController(IEntityBaseRepository<AddOn> productsAddOnRepository,
            IEntityBaseRepository<Error> _errorsRepository, IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _productsAddOnRepository = productsAddOnRepository;
        }

        // GET: api/plans
        [Route("AddOnlist")]
        [HttpGet]
        public HttpResponseMessage GetAddOn(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                var productAddOn = _productsAddOnRepository.GetAll().OrderByDescending(m => m.ID).ToList();

                response = request.CreateResponse<IEnumerable<AddOn>>(HttpStatusCode.OK, productAddOn);

                return response;
            });
        }

        // GET: api/Plans/5
        [Route("AddOnlist/{id:int}")]
        [ResponseType(typeof(Plan))]
        public HttpResponseMessage GetProduct(HttpRequestMessage request, int id)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var addOn = _productsAddOnRepository.GetSingle(id);

                response = request.CreateResponse<AddOn>(HttpStatusCode.OK, addOn);

                return response;
            });
        }

        // PUT: api/Plans/5
        //[Route("Plans")]
        //[ResponseType(typeof(void))]
        //public async Task<IHttpActionResult> PutProduct(int id, Product gadget)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    if (id != gadget.ProductId)
        //    {
        //        return BadRequest();
        //    }

        //    db.Entry(gadget).State = EntityState.Modified;

        //    try
        //    {
        //        await db.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!ProductExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return StatusCode(HttpStatusCode.NoContent);
        //}

        //// POST: api/Plans
        //[Route("Plans")]
        //[ResponseType(typeof(Product))]
        //public async Task<IHttpActionResult> PostProduct(Product gadget)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    db.Products.Add(gadget);
        //    await db.SaveChangesAsync();

        //    return CreatedAtRoute("DefaultApi", new { id = gadget.ProductId }, gadget);
        //}

        //// DELETE: api/Plans/5
        //[Route("Plans")]
        //[ResponseType(typeof(Product))]
        //public async Task<IHttpActionResult> DeleteProduct(int id)
        //{
        //    Product gadget = await db.Products.FindAsync(id);
        //    if (gadget == null)
        //    {
        //        return NotFound();
        //    }

        //    db.Products.Remove(gadget);
        //    await db.SaveChangesAsync();

        //    return Ok(gadget);
        //}

        
    }
}